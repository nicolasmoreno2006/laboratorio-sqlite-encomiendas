# Encomiendas – Persistencia local con SQLite

Módulo Android (Java) que registra **encomiendas**, sus **remitentes** y **destinatarios** en SQLite
usando `SQLiteOpenHelper`, `ContentValues`, `insert()` y `rawQuery()`, como en la presentación del curso.

## Modelo de datos (`encomiendas.db`, versión 1)

```
REMITENTE (_id, NOMBRE, DOCUMENTO UNIQUE, TELEFONO, DIRECCION, CIUDAD)
DESTINATARIO (_id, NOMBRE, DOCUMENTO UNIQUE, TELEFONO, DIRECCION, CIUDAD)
ENCOMIENDA (_id, GUIA UNIQUE, DESCRIPCION, PESO_KG, VALOR_DECLARADO, TIPO_ENVIO,
            FECHA_REGISTRO, REMITENTE_ID → REMITENTE, DESTINATARIO_ID → DESTINATARIO)
```

Un remitente o destinatario puede tener muchas encomiendas. Si se registra otra encomienda con un
documento ya existente, se reutiliza la persona (y se actualizan sus datos).

## Archivos

| Archivo | Qué hace |
|---|---|
| `EncomiendasDbHelper.java` | Crea las tablas (`onCreate`), las recrea (`onUpgrade`), inserta en una transacción y consulta con `JOIN` |
| `Persona`, `Remitente`, `Destinatario`, `Encomienda` | Clases del modelo |
| `RegistroActivity` + `activity_registro.xml` | Formulario de captura. Botón **Registrar encomienda** → guarda en SQLite |
| `ConsultaActivity` + `activity_consulta.xml` | Botón **Consultar encomiendas** → lista todo, busca por guía o documento y muestra el detalle |

## Cómo usarlo

**Proyecto nuevo:** abre la carpeta `encomiendas` en Android Studio y deja que sincronice Gradle.

**Proyecto existente:** copia las clases Java a tu paquete (cambia la línea `package`), los dos layouts a
`res/layout`, los estilos `TituloSeccion` y `Campo` de `themes.xml`, registra las dos actividades en el
`AndroidManifest.xml` y verifica que tengas la dependencia
`com.google.android.material:material` (los proyectos nuevos de Android Studio ya la traen).

## Ver la base de datos

En Android Studio: **View → Tool Windows → App Inspection → Database Inspector**, con la app corriendo.
El archivo queda en `/data/data/co.edu.unipiloto.encomiendas/databases/encomiendas.db`.
