package co.edu.unipiloto.encomiendas;

/** Persona que recibe la encomienda. */
public class Destinatario extends Persona {
    public Destinatario(String nombre, String documento, String telefono,
                        String direccion, String ciudad) {
        super(nombre, documento, telefono, direccion, ciudad);
    }
}
